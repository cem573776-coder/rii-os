gcc -ffreestanding -c kernel.c
gcc -ffreestanding -c gfx.c
gcc -ffreestanding -c syscall.c

ld -T linker.ld -o kernel.bin kernel.o gfx.o syscall.o