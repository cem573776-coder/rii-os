#define RIIBOOT_EXPORTS
#include "dll.h"
#include <iostream>

// Boot bilgisi örneği
static BootInfo bootInfo = {800, 600, 0xA0000, 32};

extern "C" {

void InitBoot() {
    // Kernel ile bağlantı ve framebuffer setup
    // Örnek pseudocode:
    // bootInfo.framebufferAddr = KERNEL_GetFramebufferAddress();
    // bootInfo.screenWidth = KERNEL_GetWidth();
    // bootInfo.screenHeight = KERNEL_GetHeight();
    // bootInfo.colorDepth = KERNEL_GetColorDepth();
}

BootInfo GetBootInfo() {
    InitBoot();
    return bootInfo;
}

void ShowBootScreen() {
    // Kernel framebuffer’ına basit boot ekranı çiz
    // Örnek: grid veya logo
    std::cout << "Rii OS Booting...\n";
    // kernel framebuffer update pseudocode
    // drawLogo(bootInfo.framebufferAddr);
}

}