#include <stdint.h>

uint32_t* framebuffer;
uint32_t screen_width;
uint32_t screen_height;
uint32_t pitch;

void putpixel(uint32_t x, uint32_t y, uint32_t color)
{
    framebuffer[y * (pitch / 4) + x] = color;
}

void draw_screen()
{
    for(uint32_t y = 0; y < screen_height; y++)
    {
        for(uint32_t x = 0; x < screen_width; x++)
        {
            if((x / 50) % 2 == 0)
                putpixel(x, y, 0x00FF0000); // Kırmızı
            else
                putpixel(x, y, 0x00000000); // Siyah
        }
    }
}

void kernel_main()
{
    draw_screen();

    while(1);
}