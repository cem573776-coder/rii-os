void kmain()
{
    char* video = (char*)0xB8000;
    video[0] = 'R';
    video[2] = 'İ';
    video[4] = 'İ';
    video[6] = ' ';
    video[8] = 'O';
    video[10] = 'S';
    video[12] = ' ';
    video[14] = 'A';
    video[16] = 'L';
    video[18] = 'P';
    video[20] = 'A';
    video[22] = ' ';
    video[24] = '0';
    video[26] = '.';
    video[28] = '1';

    while (1)
    {
    }
}