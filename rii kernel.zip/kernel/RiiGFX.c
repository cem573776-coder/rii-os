#include "Riigfxlib.c"

#define WIDTH 800
#define HEIGHT 600
#define FB_ADDR 0xE0000000

unsigned int* framebuffer = (unsigned int*)FB_ADDR;

void gfx_clear(unsigned int color)
{
    for(int y = 0; y < HEIGHT; y++)
        for(int x = 0; x < WIDTH; x++)
            framebuffer[y * WIDTH + x] = color;
}

void gfx_pixel(int x, int y, unsigned int color)
{
    framebuffer[y * WIDTH + x] = color;
}