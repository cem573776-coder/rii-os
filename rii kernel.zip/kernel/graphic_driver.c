
// Rii OS - graphic_driver.c
// Simple VGA text mode driver

#include <stdint.h>

#define VGA_MEMORY (uint16_t*)0xB8000
#define VGA_WIDTH 80
#define VGA_HEIGHT 25

static uint8_t cursor_x = 0;
static uint8_t cursor_y = 0;

void graphics_clear() {
    for(int y = 0; y < VGA_HEIGHT; y++) {
        for(int x = 0; x < VGA_WIDTH; x++) {
            VGA_MEMORY[y * VGA_WIDTH + x] = (0x07 << 8) | ' ';
        }
    }
    cursor_x = 0;
    cursor_y = 0;
}

void graphics_putc(char c) {
    if(c == '\n') {
        cursor_x = 0;
        cursor_y++;
        return;
    }

    VGA_MEMORY[cursor_y * VGA_WIDTH + cursor_x] = (0x07 << 8) | c;
    cursor_x++;

    if(cursor_x >= VGA_WIDTH) {
        cursor_x = 0;
        cursor_y++;
    }
}

void graphics_print(const char* str) {
    while(*str) {
        graphics_putc(*str++);
    }
}
