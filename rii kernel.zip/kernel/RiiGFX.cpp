// riigfx.sys

#include <stdint.h>

#define SCREEN_WIDTH  800
#define SCREEN_HEIGHT 600
#define FRAMEBUFFER_ADDRESS 0xE0000000

uint32_t* framebuffer = (uint32_t*)FRAMEBUFFER_ADDRESS;

void gfx_init()
{
    // GPU init burada olur (gerçek sistemde PCI scan gerekir)
}

void gfx_putpixel(int x, int y, uint32_t color)
{
    framebuffer[y * SCREEN_WIDTH + x] = color;
}

void gfx_clear(uint32_t color)
{
    for(int y = 0; y < SCREEN_HEIGHT; y++)
    {
        for(int x = 0; x < SCREEN_WIDTH; x++)
        {
            gfx_putpixel(x, y, color);
        }
    }
}