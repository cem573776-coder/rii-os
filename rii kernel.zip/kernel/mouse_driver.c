
// Rii OS - mouse_driver.c
// Simple PS/2 mouse driver skeleton

#include <stdint.h>

#define MOUSE_DATA_PORT 0x60
#define MOUSE_STATUS_PORT 0x64

static int mouse_x = 0;
static int mouse_y = 0;

void mouse_init() {
    // In real OS: enable mouse device + IRQ12
}

void mouse_update() {
    uint8_t data;
    __asm__ __volatile__("inb %1, %0" : "=a"(data) : "Nd"(MOUSE_DATA_PORT));

    // Very simplified movement handling
    mouse_x += (int8_t)data;
    mouse_y += (int8_t)data;
}

int mouse_get_x() {
    return mouse_x;
}

int mouse_get_y() {
    return mouse_y;
}
