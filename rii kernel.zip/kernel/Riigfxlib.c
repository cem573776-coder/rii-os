#ifndef GFX_H
#define GFX_H

void gfx_clear(unsigned int color);
void gfx_pixel(int x, int y, unsigned int color);

#endif