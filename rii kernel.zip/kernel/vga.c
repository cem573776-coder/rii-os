#include "vga.h"

#define VGA_ADDRESS 0xB8000
#define WIDTH 80
#define HEIGHT 25

unsigned short* vga = (unsigned short*)VGA_ADDRESS;
unsigned char color = 0x0F;
int cursor = 0;

void vga_clear()
{
    for(int i = 0; i < WIDTH * HEIGHT; i++)
        vga[i] = (color << 8) | ' ';
    
    cursor = 0;
}

void vga_print(const char* str)
{
    while(*str)
    {
        vga[cursor++] = (color << 8) | *str;
        str++;
    }
}
