#include "vga..c"

void kernel_main()
{
    vga_clear();
    vga_print("Rii OS Basladi!");

    while(1);
}