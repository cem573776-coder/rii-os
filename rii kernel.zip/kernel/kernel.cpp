extern "C" void kmain();

#define VIDEO_MEMORY 0xB8000

unsigned char inportb(unsigned short port)
{
    unsigned char rv;
    asm volatile ("inb %1, %0" : "=a"(rv) : "dN"(port));
    return rv;
}

void putc(char c)
{
    static int x = 0;
    static int y = 0;

    char* video = (char*)VIDEO_MEMORY;

    video[(y * 80 + x) * 2] = c;
    video[(y * 80 + x) * 2 + 1] = 0x07;

    x++;

    if (x >= 80)
    {
        x = 0;
        y++;
    }
}

void print(const char* str)
{
    int i = 0;

    while (str[i])
    {
        putc(str[i]);
        i++;
    }
}

char keymap[128] =
{
0,27,'1','2','3','4','5','6','7','8','9','0','-','=',8,
'\t','q','w','e','r','t','y','u','i','o','p','[',']','\n',0,
'a','s','d','f','g','h','j','k','l',';','\'','`',0,'\\',
'z','x','c','v','b','n','m',',','.','/',0,'*',0,' ',
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0
};

char getkey()
{
    while (!(inportb(0x64) & 1));

    unsigned char scancode = inportb(0x60);

    if (scancode > 128)
        return 0;

    return keymap[scancode];
}

void shell()
{
    print("\nRii OS Core Shell\n");
    print("> ");

    while (1)
    {
        char c = getkey();

        if (c)
        {
            putc(c);
        }
    }
}

extern "C" void kmain()
{

    print("Rii OS Core Booted\n");

    shell();

    while (1);

}