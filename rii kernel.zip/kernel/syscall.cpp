#include "Riigfxlib.c"

void syscall_handler(int eax, int ebx, int ecx, int edx)
{
    switch(eax)
    {
        case 1:
            gfx_clear(ebx);
            break;

        case 2:
            gfx_pixel(ebx, ecx, edx);
            break;
    }
}