
// Rii OS - keyboard_driver.c
// Simple PS/2 keyboard driver skeleton

#include <stdint.h>

#define KEYBOARD_DATA_PORT 0x60

static uint8_t last_key = 0;

void keyboard_init() {
    // In real OS: enable keyboard IRQ (IRQ1)
}

uint8_t keyboard_read_scancode() {
    uint8_t scancode;
    __asm__ __volatile__("inb %1, %0" : "=a"(scancode) : "Nd"(KEYBOARD_DATA_PORT));
    last_key = scancode;
    return scancode;
}

uint8_t keyboard_get_last_key() {
    return last_key;
}
